Arduino communicating with Node.js Experiment.
To make this work you will need to download the socket.io and serialPort
modules in the node_modules folder. 

The application is run by executing index.js (node index.js)

THIS IS AN EXPERIMENT AND THEREFORE FAR FROM PERFECT !

Barry